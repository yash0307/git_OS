Specification-1 : Done, if pwd is behind the starting directory then absolut		      -e path of this directory is shown.
Specification-2 : cd, pwd, echo done. echo also gives results for environmen		      -t variables
Specification-3 : Done
